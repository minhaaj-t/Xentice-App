const COLORS = {
  white: '#FFF',
  dark: '#000',
  primary: '#0E86D4',
  secondary: '#e0f4f1',
  light: '#f9f9f9',
  grey: '#908e8c',
  orange: '#f5a623',
};

export default COLORS;
