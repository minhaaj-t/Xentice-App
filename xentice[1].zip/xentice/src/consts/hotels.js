const hotels = [
  {
    id: '1',
    name: 'Woxro Office',
    location: 'Thrissur',
    price: 120,
    image: require('../assets/hotel1.jpg'),
    details: `Woxro is a trusted global website designing company that provides full-cycle software development services, e-commerce & Mobile App development.
`,
  },
  {
    id: '2',
    name: 'Woxro Office',
    location: 'Kerala',
    price: 70,
    image: require('../assets/hotel2.jpg'),
    details: `Woxro is a trusted global website designing company that provides full-cycle software development services, e-commerce & Mobile App development.
`,
  },
  {
    id: '3',
    name: 'Woxro Office',
    location: 'Kochi',
    price: 90,
    image: require('../assets/hotel3.jpg'),
    details: `Woxro is a trusted global website designing company that provides full-cycle software development services, e-commerce & Mobile App development.
`,
  },
  {
    id: '4',
    name: 'Woxro Office',
    location: 'Kannur',
    price: 100,
    image: require('../assets/hotel4.jpg'),
    details: `Woxro is a trusted global website designing company that provides full-cycle software development services, e-commerce & Mobile App development.
`,
  },
];

export default hotels;
